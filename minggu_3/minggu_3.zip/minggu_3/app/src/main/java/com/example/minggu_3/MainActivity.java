package com.example.minggu_3;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import com.example.minggu_3.navigator.pushReplacement;

public class MainActivity extends AppCompatActivity {
    pushReplacement push = new pushReplacement();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActionBar bar = getSupportActionBar();
        bar.hide();
        setContentView(R.layout.activity_main);
        pushToList();
    }

    Button btn_list, btn_recycler;

    private void pushToList(){
        btn_list = (Button)findViewById(R.id.btn_listView);
        btn_list.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                push.pushReplacement(getApplicationContext(), ListView.class);
            }
        });
    }
}